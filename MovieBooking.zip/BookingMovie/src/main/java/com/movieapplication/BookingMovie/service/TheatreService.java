package com.movieapplication.BookingMovie.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieapplication.BookingMovie.dao.ShowDao;
import com.movieapplication.BookingMovie.dao.TheaterDao;
import com.movieapplication.BookingMovie.dto.TheaterDto;
import com.movieapplication.BookingMovie.model.Show;
import com.movieapplication.BookingMovie.model.Theatre;
@Service
public class TheatreService {
	@Autowired 
	TheaterDao theatreDao;
	@Autowired
	ShowDao showDao;
	public String addTheaterDetails(Theatre user){
		 theatreDao.save(user);
		 return "Successful created";
	}
	public List<TheaterDto> detailsByMoviename(String moviename){
		System.out.println("abcde");
		List<Theatre> th=theatreDao.findByName(moviename);
		List<TheaterDto> displaylist=new ArrayList<TheaterDto>();
		List<Show> show=showDao.findByMovieName(moviename);
		//List<Show> showlist=show.stream().filter(x->x.getMorningShow().equals(moviename)||x.getEveningShow().equals("evening_show")||x.getNoonShow().equals("noon_show")).collect(Collectors.toList());
		for(int i=0;i<show.size();i++){
			System.out.println(show.get(i).getShowId()+""+show.get(i).getTheatreId()+" "+show.get(i).getMorningShow()+""+show.get(i).getNoonShow()+""+show.get(i).getEveningShow());
		}
		for(int i=0;i<th.size();i++){
			TheaterDto th1=new TheaterDto();
			th1.setName(th.get(i).getName());
			th1.setPlace(th.get(i).getPlace());
			if(moviename.equals(show.get(i).getMorningShow())){
				th1.setShow("MORNING");
			}
			else if(moviename.equals(show.get(i).getNoonShow())){
				th1.setShow("Afternoon");
			}
			else if(moviename.equals(show.get(i).getEveningShow())){
				th1.setShow("Evening");
			}
			
			displaylist.add(th1);
		}
		return displaylist;
	}
}
