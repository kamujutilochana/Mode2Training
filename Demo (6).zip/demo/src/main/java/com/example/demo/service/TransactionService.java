package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.AccountDao;
import com.example.demo.DAO.TransactionDao;
import com.example.demo.model.Account;
import com.example.demo.dto.SendData;
import com.example.demo.exception.AccountNotFound;
import com.example.demo.exception.InsufficientBalance;
import com.example.demo.model.Transaction;
@Service
public class TransactionService {
	@Autowired
	TransactionDao tDao;
	@Autowired
	AccountDao adao;
	ModelMapper mapper=new ModelMapper();
	List<SendData> list=new ArrayList<SendData>();
		/*checkBalance is a method to check balance and account is found or not then update both credit and debit Transactions at a time in Transaction table*/
		public String checkBalance(com.example.demo.dto.SendData data){
			//Integer accnum=Integer.parseInt(accno);
		/*	Account a=new Account();
			list.add(mapper.map(a,SendData.class));*/
			Account a1=adao.findById(data.getFromaccno()).orElse(null);
			Account a2=adao.findById(data.getToaccno()).orElse(null);
				if(a1==null){
					 throw new AccountNotFound("account not found"+a1);
				}
				if(a1.getBalance()>data.getAmount()){
					
					String str=addtransaction(data,a1);
					String str1=totransaction(data,a2);
					return str;
				}
				throw new InsufficientBalance("insufficient balance");
				
		}
		/* To add credit Transaction in Transaction Table */
		public String addtransaction(SendData Data,Account a1){
			Transaction t=new Transaction();
			t.setAccnum(Data.getFromaccno());
			t.setAmount(Data.getAmount());
			t.setType("credit");
			t.setDescription("send amount to other person");
			tDao.save(t);
			int amount=a1.getBalance()-Data.getAmount();
			a1.setBalance(amount);
			adao.save(a1);
			return "Transaction Successfully";
		}
		/* To add Debit Transaction in Transaction Table */
		public String totransaction(SendData Data,Account a1){
			Transaction t=new Transaction();
			t.setAccnum(Data.getToaccno());
			t.setAmount(Data.getAmount());
			t.setType("debit");
			t.setDescription("receive amount to other person");
			tDao.save(t);
			int amount=a1.getBalance()+Data.getAmount();
			a1.setBalance(amount);
			adao.save(a1);
			return "Transaction Successfully";
		}
		/* To get Transaction Details By paging and sorting concept */
		public List<Transaction> getTransactionDetails(Integer pageno,Integer pageSize,String sortBy){
			Pageable paging = PageRequest.of(pageno, pageSize, Sort.by(sortBy));
			 
	        Page<Transaction> pagedResult =tDao.findAll(paging);
	         
	        if(pagedResult.hasContent()) {
	            return pagedResult.getContent();
	        } else {
	            return new ArrayList<Transaction>();
	        }
			
		}
}
