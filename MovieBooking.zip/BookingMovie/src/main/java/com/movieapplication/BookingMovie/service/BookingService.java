package com.movieapplication.BookingMovie.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieapplication.BookingMovie.dao.BookingDao;
import com.movieapplication.BookingMovie.model.Booking;

@Service
public class BookingService {
	@Autowired 
	BookingDao bookingDao;
	public String addBookingDetails(String moviename,String theatername,String showtime){
		int id=1;
		Booking booking =new Booking();
		booking.setMovieName(moviename);
		booking.setTheatreName(theatername);
		booking.setShowTime(showtime);
		LocalDate local=LocalDate.now();
		booking.setDate(local);
		booking.setUserid(id++);
		 bookingDao.save(booking);
		 return "Successful created";
	}
}
