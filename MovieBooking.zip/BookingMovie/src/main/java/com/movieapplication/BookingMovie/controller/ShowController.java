package com.movieapplication.BookingMovie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.movieapplication.BookingMovie.model.Show;
import com.movieapplication.BookingMovie.service.ShowService;

@RestController
public class ShowController {
	@Autowired
	ShowService showservice;
	@PostMapping(value="show/add")
	public String addShowDetails(@RequestBody Show show){
		String str=showservice.addShowDetails(show);
		return str;
	}
}
