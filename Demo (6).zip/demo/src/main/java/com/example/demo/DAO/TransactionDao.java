package com.example.demo.DAO;


import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.model.Transaction;

public interface TransactionDao extends  PagingAndSortingRepository<Transaction,String>{
	
}
