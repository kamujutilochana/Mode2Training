package com.pack.student.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.student.dao.StudentDao;
import com.pack.student.model.College;
import com.pack.student.model.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDao studentDao;
	
	
	@Transactional
	public void addStudent(Student student) {
		studentDao.addStudent(student);
		
	}
	/*
	 * @Transactional public List<College> studentdetails(String usn) { return
	 * studentDao.getStudentplaceDetails(usn); }
	 */
}
