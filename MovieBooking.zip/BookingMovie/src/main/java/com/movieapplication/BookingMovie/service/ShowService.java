package com.movieapplication.BookingMovie.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.movieapplication.BookingMovie.dao.ShowDao;
import com.movieapplication.BookingMovie.model.Show;


@Service
public class ShowService {
	@Autowired 
	ShowDao showdao;
	public String addShowDetails(Show show){
		LocalDate localDate = LocalDate.now();
		show.setDate(localDate);
		showdao.save(show);
		 return "Successful created";
	}
}
