package com.pack.student.controller;



import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.student.model.College;
import com.pack.student.model.Student;
import com.pack.student.service.CollegeService;
import com.pack.student.service.StudentService;



@Controller
public class CollegeController {
private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
	
	@Autowired
	private CollegeService collegeService;
	
	
	private Map<String, College> college = null;

	public CollegeController() {
		college = new HashMap<String, College>();
	}
	
	
	@ModelAttribute("college")
	public College creatCollegeModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new College();
	}
	/*@RequestMapping(value = "/cust/add", method = RequestMethod.GET)
	@ResponseBody
	List<Customer> getAllCustomer(){
		return null;
	}
	
	@RequestMapping(value = "/cust/save.do", method = RequestMethod.POST)
	void saveCustomerDetails(@RequestBody Customer customer){
		
	
}*/
	@RequestMapping(value = "/college/add", method = RequestMethod.GET)
	public String addCollege(Model model) {
		logger.info("Returning collegedetails.jsp page");
		// model.addAttribute("user", new User());
		return "collegedetails";
	}
	@RequestMapping(value = "/college/save.do", method = RequestMethod.POST)
	public String saveCollegeAction(@ModelAttribute("college") @Validated College college, BindingResult bindingResult,
			Model model) {
	
		if (bindingResult.hasErrors()) {
			logger.info("Returning collegedetails.jsp page");
			return "collegedetails";
		}
		logger.info("Returning success.jsp page");
		model.addAttribute("college", college);
		// customers.put(customer.getEmail(), customer);
		this.collegeService.addCollege(college);
		return "success";
	}
	@RequestMapping(value = "/student/details", method = RequestMethod.GET)
	public String getdetails(Student student,Model model) {
		logger.info("Returning details.jsp page");
		model.addAttribute("student", new Student());
		return "details";


	}
}
