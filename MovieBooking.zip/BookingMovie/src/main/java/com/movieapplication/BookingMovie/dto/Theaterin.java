package com.movieapplication.BookingMovie.dto;

public interface Theaterin {
	
}
