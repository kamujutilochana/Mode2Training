package com.movieapplication.BookingMovie.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.movieapplication.BookingMovie.dao.MovieDao;
import com.movieapplication.BookingMovie.model.Movie;
import com.movieapplication.BookingMovie.model.Theatre;


@Service
public class MovieService {
	@Autowired 
	MovieDao moviedao;
	public String addMovieDetails(Movie movie){
		//LocalDate localDate = LocalDate.now();
		//movie.setReleaseDate(localDate);
		 moviedao.save(movie);
		 return "Successful created";
	}
	/*public List<Theatre> detailsByMoviename(String moviename){
		List<Theatre> th=moviedao.findByNameandPlace(moviename);
		for(int i=0;i<th.size();i++){
			System.out.println(th.get(i).getName());
			System.out.println(th.get(i).getPlace());
		}
		return th;
	}*/
}
