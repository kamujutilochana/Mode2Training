package com.movieapplication.BookingMovie.dao;

import org.springframework.data.repository.CrudRepository;

import com.movieapplication.BookingMovie.model.User;

public interface UserDao extends CrudRepository<User,String>{

}
