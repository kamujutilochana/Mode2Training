package com.pack.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.pack.DAO.Customeracc;
import com.pack.model.Customer;


public class Customerservice {
	@Autowired
	private Customeracc cust;
	/* Service method to save Customer details in Database*/
	@Transactional
	public void save(Customer customer){
		System.out.println("service");
		cust.insert(customer);
		
	}
	/*Service method to retrieve Customer details from Database*/
	@Transactional
	public List<Customer> listPersons() {
		return cust.getEmployees();
	}
}
