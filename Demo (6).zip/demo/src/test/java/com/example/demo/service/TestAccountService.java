package com.example.demo.service;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.DAO.AccountDao;

@RunWith(MockitoJUnitRunner.class)
public class TestAccountService {
	@Mock
	AccountDao accountDao;
	@InjectMocks
	AccountService accountService;
	
}
