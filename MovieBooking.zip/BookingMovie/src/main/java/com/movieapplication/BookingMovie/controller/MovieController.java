package com.movieapplication.BookingMovie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.movieapplication.BookingMovie.model.Movie;
import com.movieapplication.BookingMovie.model.Theatre;
import com.movieapplication.BookingMovie.service.MovieService;

@RestController
public class MovieController {
	@Autowired
	MovieService movieservice;
	@PostMapping(value="movie/add")
	public String addMovieDetails(@RequestBody Movie movie){
		String str=movieservice.addMovieDetails(movie);
		return str;
	}
	/*@GetMapping(value="booking/add/{moviename}")
	public List<Theatre> getBookingDetails(@PathVariable(value="moviename")String moviename){
		return movieservice.detailsByMoviename(moviename);
	}*/
}
