package com.pack.student.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pack.student.model.College;

@Repository
public class CollegeDao {
	private static final Logger logger = LoggerFactory.getLogger(CollegeDao.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}

	
	public void addCollege(College college) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(college);
		
		logger.info("College added successfully");
	}
}
