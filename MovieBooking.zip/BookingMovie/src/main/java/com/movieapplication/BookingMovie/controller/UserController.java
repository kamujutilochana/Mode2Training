package com.movieapplication.BookingMovie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.movieapplication.BookingMovie.model.User;
import com.movieapplication.BookingMovie.service.UserService;
@RestController
public class UserController {
	@Autowired
	UserService userservice;
	@PostMapping(value="user/add")
	public String addUserDetails(@RequestBody User user){
		String status=userservice.addUserDetails(user);
		return status;
	}
}
