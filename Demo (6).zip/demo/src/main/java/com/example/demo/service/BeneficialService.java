package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.BeneficialDao;
import com.example.demo.model.Beneficial;

@Service
public class BeneficialService {
	@Autowired
	BeneficialDao bDao;
	/* To store Beneficial details in database */
	public String addBeneficialDetails(Beneficial ben){
		System.out.println(ben);
		//Beneficial ben1=new Beneficial();
		ben.setCustid(ben.getCustid());
		ben.setBaccno(ben.getBaccno());
		ben.setIfsc(ben.getIfsc());
		bDao.save(ben);
		return "saved successfully";
	}
	/* To get Beneficial details by using ifsc code */
	public List<Beneficial> getAllDetailsbyIFSC_code(String code){
		List<Beneficial> ben=(List<Beneficial>) bDao.findByifsc(code);
		return ben;
	}
	/*To get Beneficial details by using ifsc code and Beneficial account number */
	public List<Beneficial> getAllDetailsbyifscandBaccno(String code,String accno){
		List<Beneficial> ben=(List<Beneficial>) bDao.findByIfscAndBaccno(code, accno);
		return ben;
	}
}
