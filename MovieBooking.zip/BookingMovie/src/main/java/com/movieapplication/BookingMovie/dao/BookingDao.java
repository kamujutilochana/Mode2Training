package com.movieapplication.BookingMovie.dao;

import org.springframework.data.repository.CrudRepository;

import com.movieapplication.BookingMovie.model.Booking;

public interface BookingDao extends CrudRepository<Booking,Integer>{

}
