package com.movieapplication.BookingMovie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.movieapplication.BookingMovie.dto.TheaterDto;
import com.movieapplication.BookingMovie.model.Theatre;
import com.movieapplication.BookingMovie.service.TheatreService;

@RestController
public class TheaterController {
	@Autowired
	TheatreService theaterservice;
	@PostMapping(value="/theater/add")
	public String addTheaterDetails(@RequestBody Theatre theater){
		String str=theaterservice.addTheaterDetails(theater);
		return str;
	}
	@RequestMapping(value="/theater/show/{name}" )
	public List<TheaterDto> getBookingDetails(@PathVariable(value="name") String name){
		return theaterservice.detailsByMoviename(name);
	}
}
