package com.movieapplication.BookingMovie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.movieapplication.BookingMovie.dto.TheaterDto;
import com.movieapplication.BookingMovie.model.Theatre;
@Repository
public interface TheaterDao extends CrudRepository<Theatre,String> {
	@Query(value="select * from theatre t where t.theatre_id in (select s.theatre_id from show_table s where s.morning_show=?1 or s.evening_show=?1 or s.noon_show=?1 )",nativeQuery=true)
	List<Theatre> findByName(String name);
}
