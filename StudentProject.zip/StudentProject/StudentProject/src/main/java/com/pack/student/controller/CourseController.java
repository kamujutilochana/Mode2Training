package com.pack.student.controller;



import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.student.model.College;
import com.pack.student.model.Course;
import com.pack.student.model.Student;
import com.pack.student.service.CollegeService;
import com.pack.student.service.CourseService;
import com.pack.student.service.StudentService;



@Controller
public class CourseController {
private static final Logger logger = LoggerFactory.getLogger(CourseController.class);
	
	@Autowired
	private CourseService courseService;
	
	
	private Map<String, Course> course = null;

	public CourseController() {
		course = new HashMap<String, Course>();
	}
	
	
	@ModelAttribute("course")
	public Course creatCourseModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new Course();
	}
	/*@RequestMapping(value = "/cust/add", method = RequestMethod.GET)
	@ResponseBody
	List<Customer> getAllCustomer(){
		return null;
	}
	
	@RequestMapping(value = "/cust/save.do", method = RequestMethod.POST)
	void saveCustomerDetails(@RequestBody Customer customer){
		
	
}*/
	@RequestMapping(value = "/course/add", method = RequestMethod.GET)
	public String addCourse(Model model) {
		logger.info("Returning coursedetails.jsp page");
		// model.addAttribute("user", new User());
		return "coursedetails";
	}
	@RequestMapping(value = "/course/save.do", method = RequestMethod.POST)
	public String saveCourseAction(@ModelAttribute("course") @Validated Course course, BindingResult bindingResult,
			Model model) {
	
		if (bindingResult.hasErrors()) {
			logger.info("Returning coursedetails.jsp page");
			return "coursedetails";
		}
		logger.info("Returning success.jsp page");
		model.addAttribute("course", course);
		// customers.put(customer.getEmail(), customer);
		this.courseService.addCourse(course);
		return "success";
	}
}
