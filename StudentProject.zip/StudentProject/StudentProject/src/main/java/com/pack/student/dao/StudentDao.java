package com.pack.student.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pack.student.model.College;
import com.pack.student.model.Student;


@Repository
public class StudentDao {

		private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);

		@Autowired
		private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sf){
			this.sessionFactory = sf;
		}

		
		public void addStudent(Student student) {
			Session session = this.sessionFactory.getCurrentSession();
			session.persist(student);
			logger.info("Student added successfully");
		}
	/*
	 * @SuppressWarnings("unchecked") public List<College>
	 * getStudentplaceDetails(String usn){ List<College> lt=new
	 * ArrayList<College>(); Session session=this.sessionFactory.openSession();
	 * String query="from Student where rollno=:usn";
	 * 
	 * @SuppressWarnings("unchecked") Query query1=(Query)
	 * session.createQuery(query); ((org.hibernate.Query)
	 * query1).setString("usn",usn); List results=query1.getResultList();
	 * List<Student> List=session.createQuery("hql").list();
	 * 
	 * @SuppressWarnings("unchecked") List<College>
	 * clgList=session.createQuery("from College").list(); for(int
	 * i=0;i<List.size();i++) { if(((Student)
	 * results.get(i)).getRollno().split(clgList.get(i).getCollegecode()) != null){
	 * lt=(java.util.List<College>) session.createQuery("from College"); } } return
	 * lt; }
	 */
}
