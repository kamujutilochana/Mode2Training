package com.movieapplication.BookingMovie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.movieapplication.BookingMovie.model.Movie;
import com.movieapplication.BookingMovie.model.Theatre;

public interface MovieDao extends CrudRepository<Movie,String> {
	/*@Query(value="select * from Theatre t where t.theatre_id in (select s.theatre_id from Show_table s where s.morning_show= :moviename or s.evening_show=:moviename or s.noon_show=:moviename)",nativeQuery=true)
		List<Theatre> findByNameandPlace(@Param("moviename") String moviename);*/
}
