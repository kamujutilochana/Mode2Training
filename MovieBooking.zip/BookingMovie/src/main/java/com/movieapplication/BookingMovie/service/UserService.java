package com.movieapplication.BookingMovie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieapplication.BookingMovie.dao.UserDao;
import com.movieapplication.BookingMovie.model.User;

@Service
public class UserService {
	@Autowired 
	UserDao userdao;
	public String addUserDetails(User user){
		 userdao.save(user);
		 return "Successful created";
	}
}
