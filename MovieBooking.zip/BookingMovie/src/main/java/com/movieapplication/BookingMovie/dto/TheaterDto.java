package com.movieapplication.BookingMovie.dto;

public class TheaterDto {
	String name;
	String place;
	String show;
	
	public TheaterDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TheaterDto(String name, String place,String show) {
		super();
		this.name = name;
		this.place = place;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}
	
	
}
