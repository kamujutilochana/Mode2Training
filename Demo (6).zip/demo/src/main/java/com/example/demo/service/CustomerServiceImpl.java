package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.example.demo.DAO.CustomerDao;
import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Customer;
@Service
public class CustomerServiceImpl {
	@Autowired
	CustomerDao custDao;
	ModelMapper mapper=new ModelMapper();
	List<CustomerDto> list=new ArrayList<CustomerDto>();
	private int cust=1;
	/* add customer Details based on conditions */
	public String addCustomerDetails(Customer customer){
		if(customer.getAge()>=21){
				customer.setEmpId((cust++));
				customer.setPassword("HCL"+customer.getcustId());
				custDao.save(customer);
				return "Successful registered";
		}
		else{
			return "Age should be greater than 21";
		}
		
	}
	/* Update Customer Details by Customer Id */
	public void updateCustomer(int id,Customer customer){
			Customer customer1 = custDao.findById(id).orElse(null);
			customer1.setJob(customer.getJob());
			customer1.setEmail(customer.getEmail());
			customer1.setPhno(customer.getPhno());
			custDao.save(customer1);
	}
	/* get all Customer Details using DTO class */
	public List<CustomerDto> getAllCustomers(){
		  custDao.findAll().forEach(customer->convertTo(customer));
		  return list;
	}
	private void convertTo(Customer customer) {
		list.add(mapper.map(customer,CustomerDto.class));
		
	}
	/* To delete customer details by passing customer Id */
	public String deleteCustomers(int id){
		custDao.deleteById(id);
		return "delete Successfully";
	}
	/* To get Customer Details by customer Id */
	public Customer getCustomerById(int id){
		return custDao.findById(id).orElse(null);
		
	}
	/* To get Customer Details sort by age using PagingandSorting Repository */
	public List<Customer> getCustomerDetailbyAge(String sortBy){
		Sort sortOrder = Sort.by(sortBy);
		 
		return  (List<Customer>) custDao.findAll(sortOrder);
         
		
	}
	
}
