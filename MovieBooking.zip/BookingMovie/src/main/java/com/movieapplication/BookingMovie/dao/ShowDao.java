package com.movieapplication.BookingMovie.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.movieapplication.BookingMovie.model.Show;

public interface ShowDao extends CrudRepository<Show,String>{
	@Query(value="select * from show_table s where s.morning_show= ?1 or s.evening_show=?1 or s.noon_show=?1",nativeQuery=true)
	List<Show> findByMovieName(String moviename);
}
