package com.movieapplication.BookingMovie.dto;

import java.time.LocalDate;

public class DisplayDto {
	String theatreId;
	String name;
	String place;
	String showId;
	String morningShow;
	String noonShow;
	String eveningShow;
	LocalDate date;
	public String getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getMorningShow() {
		return morningShow;
	}
	public void setMorningShow(String morningShow) {
		this.morningShow = morningShow;
	}
	public String getNoonShow() {
		return noonShow;
	}
	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}
	public String getEveningShow() {
		return eveningShow;
	}
	public void setEveningShow(String eveningShow) {
		this.eveningShow = eveningShow;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
}
