package com.example.demo.DAO;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Account;

public interface AccountDao extends CrudRepository<Account,String>{
	
}
