package com.movieapplication.BookingMovie.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ShowTable")
public class Show {
	@Id
	String showId;
	String theatreId;
	String morningShow;
	String noonShow;
	String eveningShow;
	LocalDate date;
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}
	public String getMorningShow() {
		return morningShow;
	}
	public void setMorningShow(String morningShow) {
		this.morningShow = morningShow;
	}
	public String getNoonShow() {
		return noonShow;
	}
	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}
	public String getEveningShow() {
		return eveningShow;
	}
	public void setEveningShow(String eveningShow) {
		this.eveningShow = eveningShow;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
}
