package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank1")
public class Customer {
		@Id
		@Column(name="custid")
			private int custid;
		@Column(name="name")
			private String name;
		@Column(name="age")
		private int age;
		@Column(name="Phno")
		private long phno;
		@Column(name="email")
		private String email;
		@Column(name="job")
		private String job;
		@Column(name="password")
		private String password;
		public int getcustId() {
			return custid;
		}
		public void setEmpId(int custId) {
			this.custid = custId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public long getPhno() {
			return phno;
		}
		public void setPhno(long phno) {
			this.phno = phno;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getJob() {
			return job;
		}
		public void setJob(String job) {
			this.job = job;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
	
}
