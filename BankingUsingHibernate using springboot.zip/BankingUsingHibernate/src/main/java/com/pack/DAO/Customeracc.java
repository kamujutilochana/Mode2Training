package com.pack.DAO;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.pack.model.Customer;

public class Customeracc {
	private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    /* Insert customer details in database using Hibernate Query Language*/
    @Transactional
	public void insert(Customer customer){
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(customer);
		tx.commit();
		session.close();
	}
    /* Retrieve details from customer database using Hibernate Query Language*/
    @Transactional
	public List<Customer> getEmployees(){
	  Session session = this.sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		List<Customer> EmpolyeesList = session.createQuery("from Customer").list();
		for(int i=0;i<EmpolyeesList.size();i++){
			System.out.println(EmpolyeesList.get(i).getName()+" "+EmpolyeesList.get(i).getAge()+" "+EmpolyeesList.get(i).getEmail());
		}
		session.close();
	    return EmpolyeesList;
	}  
}
