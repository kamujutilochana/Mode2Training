package com.pack;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
@Repeatable(AccessingElements.class)
@interface Customer {
    String   name();
    int      age();
    String phno();
    String accno();
    float amount();
} 
@Retention(RetentionPolicy.RUNTIME)
@interface AccessingElements{
	Customer[] value();
}
/* using java8 and custom annotations concepts */
@Customer(name="Tilochana",age=21,phno="1234567890",accno="59085055",amount=50000)
@Customer(name="Sravya",age=18,phno="798465213213",accno="7895462130",amount=50000)
public class AccountValid {
	//To check validCustomers based on conditions using filter concept from java8 and maintain OLD Transaction history also*/
	public static void main(String args[]) {
		System.out.println("enter the account no");
		Scanner sc = new Scanner(System.in);
		String a = "";
		String b = "SBI";
		List<String> customersList = new ArrayList<String>();
		for (int i = 0; i < 3; i++) {
			a = sc.next();
			customersList.add(a);
		}
		List validAccountnumbers = customersList.stream().map(x -> (b.concat(x))).filter(i -> i.length() == 8).collect(Collectors.toList());
		System.out.println("Valid account numbers"+validAccountnumbers);
		List invalidAccountNumbers = customersList.stream().map(x -> (b.concat(x))).filter(i -> i.length() != 8).collect(Collectors.toList());
		System.out.println("Invalid account numbers"+invalidAccountNumbers);
		
		System.out.println("enter the customer name,age,phno");
		Customer[]  cust=AccountValid.class.getAnnotationsByType(Customer.class);
		List<Customer> customer=new ArrayList<Customer>();
		for(Customer c:cust){
			customer.add(c);
		}
		for(int i=0;i<customer.size();i++){
			System.out.println(""+customer.get(i).name()+""+customer.get(i).age()+""+customer.get(i).phno());
		}
		List<Customer> validCustomers = customer.stream().filter(x ->(x.name().matches("[A-Z][a-z]*"))&&(x.age() >=18)&&(x.phno().matches("[0-9].*")&&x.phno().length()==10)).collect(Collectors.toList());
		for(int i=0;i<validAccountnumbers.size()&&i<validCustomers.size();i++){
				String accnum=(String) validAccountnumbers.get(i);
				String custacc=validCustomers.get(i).accno();
				custacc=accnum;
			
		}
		for(int i=0;i<validCustomers.size();i++){
			System.out.println(""+validCustomers.get(i).name()+" "+validCustomers.get(i).age()+" "+validCustomers.get(i).phno()+" "+validCustomers.get(i).accno()+" "+validCustomers.get(i).amount());
		}
		System.out.println("enter the customer who want to do transaction");
		String validname=sc.next();
		for(int i=0;i<validCustomers.size();i++){
			String name=validCustomers.get(i).name();
			if(validname.equals(name)){
				int n;
				String s1;
				List<String> trans=new ArrayList<String>();
				do{
					System.out.println("1:Withdraw,2:check transactions,3:exit");
					 n=sc.nextInt();
				switch(n){
					case 1:float withdraw=sc.nextFloat();
							 s1="withdraw "+withdraw;
							 trans.add(s1);
							break;
					case 2:  System.out.println("!!Your OLD TRANSACTION HISTORY");
							  System.out.println("Total no of transactions:"+trans.size());
								for(i=0;i<trans.size();i++){
									System.out.println(trans.get(i));
								}
							break;
					case 3:System.out.println("exit");
					        break;
				}
				}while(!(n==3));
			}
			else{
					System.out.println("enter valid customer name");
			}
		}
		for(int i=0;i<validCustomers.size();i++){
			System.out.println(""+validCustomers.get(i).name()+" "+validCustomers.get(i).age()+" "+validCustomers.get(i).phno()+" "+validCustomers.get(i).accno());
		}
		
	}

}
