package com.example.demo.controller;

/*import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.model.Account;
import com.example.demo.service.AccountService;
import com.example.demo.controller.AccountController*/;


//@RunWith(MockitoJUnitRunner.class)
public class TestAccountController {
/*
	@Mock
	AccountService accountService;
	@InjectMocks
	AccountController accountController;
    private MockMvc mockMvc;
   @Before
    public void setUp(){
        mockMvc = MockMvcBuilders.standaloneSetup(accountController)
                .build();
    }
   @Test
   public void addItem() throws Exception{
       String jsonString = "{\n" +
               "\"custid\":104,\n" +
               "\"accnum\":\"100\",\n" +
               "\"balance\":50000\n" +
               "}";
       Account account = new Account();
       account.setAccnum("104");
       account.setCustid(100);
       account.setBalance(50000);
       mockMvc.perform(MockMvcRequestBuilders.post("account/add")
               .contentType(MediaType.APPLICATION_JSON)
               .content(jsonString))
               .andExpect(MockMvcResultMatchers.status().is(404))
               .andExpect(MockMvcResultMatchers.jsonPath("$.custid", Matchers.is(104)))
               .andExpect(MockMvcResultMatchers.jsonPath("$.accnum",Matchers.is("100")))
               .andExpect(MockMvcResultMatchers.jsonPath("$.balance",Matchers.is(50000)));
   }
*/}
